var dboper= require('./operations')
dboper.getDetails(function (result) {
    console.log(result)
        for (var i=0;i<result.candidate.length;i++) {
            if (result.candidate[i].submitDate=='2017-06-04')
            {
                console.log(result.candidate[i].Status,result.candidate[i].Position,result.candidate[i].candidateName)
            }

            // console.log(result.candidate[i].Position)
        } })
